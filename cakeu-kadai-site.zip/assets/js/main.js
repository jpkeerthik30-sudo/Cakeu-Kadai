/* =====================================================================
   THE CAKEU KADAI — main.js
   Two-phase initialisation so the same file powers both the normal
   multi-page website and the single-file (all-pages) build:

     initGlobal() — shell elements: nav, header, tray, toast, lightbox
     initPage()   — content elements: reveal, carousel, rail, accordion,
                    filters, gallery, thumbnails, planner, forms

   Vanilla JS, no dependencies, no build step.
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- Business config (edit in one place) ---------- */
  var BIZ = {
    name: 'The Cakeu Kadai (Home Baker)',
    whatsapp: '919789184196',
    phone1: '+919789184196',
    phone2: '+919894592531',
    instagram: 'https://www.instagram.com/the_cakeu_kadai__',
    facebook: 'https://www.facebook.com/search/top?q=the%20cakeu%20kadai',
    maps: 'https://www.google.com/maps/search/?api=1&query=The+Cakeu+Kadai+Home+Baker+Periya+Poosari+St+Usilampatti+625532'
  };
  window.CAKEU = BIZ;

  var $  = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  function waLink(message) {
    return 'https://wa.me/' + BIZ.whatsapp + '?text=' + encodeURIComponent(message || '');
  }
  window.waLink = waLink;

  /* ---------- safe storage (sandboxed iframes throw on access) ---------- */
  var store = (function () {
    var ok = true, mem = {};
    try { window.localStorage.setItem('__t', '1'); window.localStorage.removeItem('__t'); }
    catch (e) { ok = false; }
    return {
      get: function (k) { try { return ok ? window.localStorage.getItem(k) : (mem[k] || null); } catch (e) { return mem[k] || null; } },
      set: function (k, v) { try { if (ok) { window.localStorage.setItem(k, v); } else { mem[k] = v; } } catch (e) { mem[k] = v; } }
    };
  })();

  /* ---------- toast ---------- */
  var toastEl = null;
  function toast(html, ms) {
    if (!toastEl || !document.body.contains(toastEl)) {
      toastEl = document.createElement('div');
      toastEl.className = 'toast';
      toastEl.setAttribute('role', 'status');
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = html;
    toastEl.classList.add('show');
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 6000);
  }
  window.cakeuToast = toast;

  /* open a link; if the browser blocks the popup, show a tappable fallback */
  function openExternal(url, message) {
    var w = null;
    try { w = window.open(url, '_blank', 'noopener'); } catch (e) { w = null; }
    if (!w || w.closed || typeof w.closed === 'undefined') {
      toast(message || ('Your browser blocked the new tab. <a href="' + url + '" target="_blank" rel="noopener">Open it here</a>.'), 9000);
      return false;
    }
    return true;
  }

  /* =====================================================================
     GLOBAL — runs once per document
     ===================================================================== */
  var lbEl = null, galItems = [], galIdx = 0, lastFocus = null;

  function buildLightbox() {
    if (lbEl) return;
    lbEl = document.createElement('div');
    lbEl.className = 'lightbox';
    lbEl.setAttribute('role', 'dialog');
    lbEl.setAttribute('aria-modal', 'true');
    lbEl.innerHTML = '<button class="lb-close" type="button" aria-label="Close">✕</button>' +
      '<button class="lb-nav prev" type="button" aria-label="Previous image">←</button>' +
      '<button class="lb-nav next" type="button" aria-label="Next image">→</button><img alt="">';
    document.body.appendChild(lbEl);

    $('.lb-close', lbEl).addEventListener('click', closeLightbox);
    $('.lb-nav.prev', lbEl).addEventListener('click', function () { showLightbox(galIdx - 1); });
    $('.lb-nav.next', lbEl).addEventListener('click', function () { showLightbox(galIdx + 1); });
    lbEl.addEventListener('click', function (e) { if (e.target === lbEl) closeLightbox(); });
    document.addEventListener('keydown', function (e) {
      if (!lbEl.classList.contains('open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') showLightbox(galIdx - 1);
      if (e.key === 'ArrowRight') showLightbox(galIdx + 1);
    });
  }
  function showLightbox(i) {
    if (!lbEl || !galItems.length) return;
    galIdx = (i + galItems.length) % galItems.length;
    var img = $('img', galItems[galIdx]);
    if (!img) return;
    var big = $('img', lbEl);
    big.src = img.getAttribute('data-full') || img.src;
    big.alt = img.alt || '';
  }
  function openLightbox(i) {
    buildLightbox();
    lastFocus = document.activeElement;
    showLightbox(i);
    lbEl.classList.add('open');
    $('.lb-close', lbEl).focus();
  }
  function closeLightbox() {
    if (!lbEl) return;
    lbEl.classList.remove('open');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  /* order tray ------------------------------------------------------- */
  var KEY = 'cakeu-order-v1';
  function getCart() { try { return JSON.parse(store.get(KEY)) || []; } catch (e) { return []; } }
  function setCart(c) { store.set(KEY, JSON.stringify(c)); renderTray(); }

  function renderTray() {
    var tray = $('.tray'), list = $('.tray ul'), count = $('.tray-count');
    if (!tray) return;
    var cart = getCart();
    tray.classList.toggle('show', cart.length > 0);
    if (count) count.textContent = cart.length + (cart.length === 1 ? ' item' : ' items');
    if (!list) return;
    list.innerHTML = cart.map(function (i, n) {
      return '<li><span>' + i.name + '</span><span>₹' + i.price +
        ' <button class="clear" type="button" data-rm="' + n + '" aria-label="Remove ' + i.name + '">✕</button></span></li>';
    }).join('');
  }

  function addToTray(btn) {
    var cart = getCart();
    cart.push({ name: btn.getAttribute('data-add'), price: btn.getAttribute('data-price') || '' });
    setCart(cart);
    var label = btn.textContent;
    btn.classList.add('added');
    btn.textContent = '✓ Added';
    setTimeout(function () { btn.classList.remove('added'); btn.textContent = label; }, 1500);
    toast('Added to your order tray — open it at the bottom left to send on WhatsApp.');
  }

  function initGlobal() {
    if (initGlobal._done) return;
    initGlobal._done = true;

    /* mobile nav — delegated so it keeps working after content swaps */
    document.addEventListener('click', function (e) {
      var b = e.target.closest('.burger');
      if (b) {
        var panel = $('.mobile-panel');
        if (panel) {
          var open = panel.classList.toggle('open');
          b.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        return;
      }
      if (e.target.closest('.mobile-panel a')) {
        var mp = $('.mobile-panel');
        if (mp) mp.classList.remove('open');
        var bg = $('.burger');
        if (bg) bg.setAttribute('aria-expanded', 'false');
      }
    });

    /* sticky header shadow */
    var header = $('.site-header');
    if (header) {
      var onScroll = function () { header.classList.toggle('is-stuck', window.scrollY > 12); };
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    /* delegated "add to order" */
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-add]');
      if (!btn) return;
      e.preventDefault();
      addToTray(btn);
    });

    /* delegated remove-from-tray */
    document.addEventListener('click', function (e) {
      var rm = e.target.closest('.tray [data-rm]');
      if (!rm) return;
      var c = getCart();
      c.splice(parseInt(rm.getAttribute('data-rm'), 10), 1);
      setCart(c);
    });

    /* tray actions */
    var clr = $('.tray .clear-all');
    if (clr) clr.addEventListener('click', function () { setCart([]); });

    var send = $('.tray .send');
    if (send) {
      send.addEventListener('click', function () {
        var cart = getCart();
        if (!cart.length) return;
        var msg = 'Hello The Cakeu Kadai! 🍰 I would like to pre-book:\n\n' +
          cart.map(function (i, n) { return (n + 1) + '. ' + i.name + (i.price ? ' — ₹' + i.price : ''); }).join('\n') +
          '\n\nName:\nDelivery date & time:\nDelivery address / pickup:\nMessage on cake:\n\n(Please confirm availability and total.)';
        openExternal(waLink(msg), 'Order ready! <a href="' + waLink(msg) + '" target="_blank" rel="noopener">Tap here to send it on WhatsApp</a>.');
      });
    }

    /* delegated form → WhatsApp */
    document.addEventListener('submit', function (e) {
      var form = e.target.closest('form[data-wa-form]');
      if (!form) return;
      e.preventDefault();
      var data = {};
      $$('input, select, textarea', form).forEach(function (f) {
        if (f.name) data[f.name] = f.value.trim ? f.value.trim() : f.value;
      });
      var kind = form.getAttribute('data-wa-form') || 'Enquiry';
      var lines = ['Hello The Cakeu Kadai! 🍰', '', '*' + kind + '*', ''];
      Object.keys(data).forEach(function (k) {
        if (!data[k]) return;
        var label = k.replace(/([A-Z])/g, ' $1').replace(/^./, function (s) { return s.toUpperCase(); });
        lines.push('• ' + label + ': ' + data[k]);
      });
      lines.push('', 'Sent from thecakeukadai website ✨');
      var url = waLink(lines.join('\n'));
      openExternal(url, 'Almost there! <a href="' + url + '" target="_blank" rel="noopener">Tap here to send your order on WhatsApp</a>.');
      var note = $('.form-sent', form.parentNode) || $('.form-sent', form);
      if (note) note.style.display = 'block';
      form.reset();
    });

    buildLightbox();
    renderTray();
  }

  /* =====================================================================
     PAGE — runs after load and after every content swap (single-file build)
     ===================================================================== */
  var revealObserver = null;

  function makeDraggable(track, onMove, onEnd) {
    if (!track || track._draggable) return;
    track._draggable = true;
    var down = false, startX = 0, startLeft = 0, moved = 0;

    function begin(x) { down = true; moved = 0; startX = x; startLeft = track.scrollLeft; track.classList.add('is-dragging'); }
    function move(x) {
      if (!down) return;
      var dx = x - startX;
      if (Math.abs(dx) > 4) moved = Math.abs(dx);
      track.scrollLeft = startLeft - dx;
      if (onMove) onMove(track.scrollLeft);
    }
    function end() {
      if (!down) return;
      down = false;
      track.classList.remove('is-dragging');
      if (onEnd) onEnd(moved);
      if (onMove) onMove(track.scrollLeft);
    }

    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (e.target.closest('button, input, select, textarea')) return;
      begin(e.clientX);
    });
    track.addEventListener('pointermove', function (e) { move(e.clientX); });
    track.addEventListener('pointerup', end);
    track.addEventListener('pointercancel', end);
    track.addEventListener('pointerleave', end);
    track.addEventListener('click', function (e) {
      if (moved > 6) { e.preventDefault(); e.stopPropagation(); }
    }, true);
    track.addEventListener('dragstart', function (e) { e.preventDefault(); });

    track.setAttribute('tabindex', track.getAttribute('tabindex') || '0');
    track.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight') { track.scrollBy({ left: 300, behavior: 'smooth' }); e.preventDefault(); }
      if (e.key === 'ArrowLeft')  { track.scrollBy({ left: -300, behavior: 'smooth' }); e.preventDefault(); }
      if (e.key === 'Home') { track.scrollTo({ left: 0, behavior: 'smooth' }); e.preventDefault(); }
      if (e.key === 'End')  { track.scrollTo({ left: track.scrollWidth, behavior: 'smooth' }); e.preventDefault(); }
    });
  }

  function initPage() {
    /* reveal on scroll (re-observe the new content) */
    var reveals = $$('.reveal');
    if (revealObserver) revealObserver.disconnect();
    if (reveals.length && 'IntersectionObserver' in window) {
      revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('in'); revealObserver.unobserve(en.target); }
        });
      }, { rootMargin: '0px 0px -6% 0px', threshold: .05 });
      reveals.forEach(function (el) { revealObserver.observe(el); });
      setTimeout(function () { reveals.forEach(function (el) { el.classList.add('in'); }); }, 2600);
    } else {
      reveals.forEach(function (el) { el.classList.add('in'); });
    }

    /* product carousel (paged arrows + dots) */
    $$('.carousel-wrap').forEach(function (wrap) {
      var track = $('.carousel', wrap);
      var prev = $('.c-arrow.prev', wrap), next = $('.c-arrow.next', wrap);
      var dotsBox = $('.dots', wrap);
      if (!track) return;

      function maxScroll() { return Math.max(0, track.scrollWidth - track.clientWidth); }
      function pageCount() { return Math.max(1, Math.ceil(maxScroll() / track.clientWidth) + 1); }
      function currentPage() {
        var max = maxScroll();
        if (max < 8) return 0;
        if (track.scrollLeft >= max - 8) return pageCount() - 1;
        return Math.min(pageCount() - 2, Math.round(track.scrollLeft / track.clientWidth));
      }
      function buildDots() {
        if (!dotsBox) return;
        var n = pageCount();
        dotsBox.innerHTML = '';
        for (var i = 0; i < n; i++) {
          (function (idx) {
            var b = document.createElement('button');
            b.type = 'button';
            b.setAttribute('aria-label', 'Go to page ' + (idx + 1));
            b.addEventListener('click', function () {
              track.scrollTo({ left: idx === n - 1 ? maxScroll() : idx * track.clientWidth, behavior: 'smooth' });
            });
            dotsBox.appendChild(b);
          })(i);
        }
      }
      function sync() {
        var i = currentPage(), n = pageCount();
        if (prev) prev.style.opacity = track.scrollLeft > 8 ? 1 : .35;
        if (next) next.style.opacity = track.scrollLeft < maxScroll() - 8 ? 1 : .35;
        if (dotsBox) $$('button', dotsBox).forEach(function (b, k) { b.classList.toggle('on', k === i); });
      }
      function go(dir) {
        var n = pageCount();
        var i = Math.min(n - 1, Math.max(0, currentPage() + dir));
        track.scrollTo({ left: i === n - 1 ? maxScroll() : i * track.clientWidth, behavior: 'smooth' });
      }
      if (prev) prev.addEventListener('click', function () { go(-1); });
      if (next) next.addEventListener('click', function () { go(1); });

      makeDraggable(track, function () { window.requestAnimationFrame(sync); });
      track.addEventListener('scroll', function () { window.requestAnimationFrame(sync); }, { passive: true });
      window.addEventListener('resize', function () { buildDots(); sync(); });
      buildDots(); sync();
    });

    /* interactive card rail */
    $$('.rail-viewport').forEach(function (vp) {
      var track = $('.rail', vp);
      var hint = $('.rail-hint', vp);
      var bar = $('.rail-progress i', vp);
      if (!track) return;

      function progress(sl) {
        var max = Math.max(1, track.scrollWidth - track.clientWidth);
        if (bar) bar.style.width = Math.min(100, Math.max(12, (sl / max) * 100)) + '%';
      }
      makeDraggable(track, progress, function (moved) {
        if (moved > 10 && hint) hint.classList.add('dismissed');
      });
      track.addEventListener('scroll', function () {
        window.requestAnimationFrame(function () { progress(track.scrollLeft); });
      }, { passive: true });
      if (hint) {
        var kill = function () { hint.classList.add('dismissed'); };
        ['pointerdown', 'touchstart', 'wheel', 'keydown'].forEach(function (ev) {
          track.addEventListener(ev, kill, { once: true, passive: true });
        });
        setTimeout(kill, 12000);
      }
      progress(track.scrollLeft);
    });

    /* FAQ accordion */
    $$('.acc-item').forEach(function (item) {
      var q = $('.acc-q', item);
      if (!q) return;
      q.setAttribute('aria-expanded', 'false');
      q.addEventListener('click', function () {
        var open = item.classList.contains('open');
        $$('.acc-item').forEach(function (o) {
          o.classList.remove('open');
          var oq = $('.acc-q', o); if (oq) oq.setAttribute('aria-expanded', 'false');
        });
        if (!open) { item.classList.add('open'); q.setAttribute('aria-expanded', 'true'); }
      });
    });

    /* menu filters + rail jump buttons */
    var filterBtns = $$('.filters button');
    if (filterBtns.length) {
      var known = filterBtns.map(function (b) { return b.getAttribute('data-filter'); });
      var applyFilter = function (cat) {
        filterBtns.forEach(function (b) {
          var on = b.getAttribute('data-filter') === cat;
          b.classList.toggle('on', on);
          b.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        $$('[data-cat]').forEach(function (card) {
          var match = cat === 'all' || card.getAttribute('data-cat').indexOf(cat) > -1;
          card.classList.toggle('hide', !match);
          if (match) card.classList.add('in');
        });
      };
      filterBtns.forEach(function (btn) {
        btn.addEventListener('click', function () { applyFilter(btn.getAttribute('data-filter')); });
      });
      var hash = (location.hash || '').replace('#', '');
      var saved = store.get('cakeu-filter');
      if (hash && known.indexOf(hash) > -1) applyFilter(hash);
      else if (saved && known.indexOf(saved) > -1) applyFilter(saved);

      $$('.rail-card[data-filter-link]').forEach(function (card) {
        if (card.tagName === 'A') return;
        card.addEventListener('click', function () {
          applyFilter(card.getAttribute('data-filter-link'));
          var grid = $('.card-grid');
          if (grid) window.scrollTo({ top: grid.getBoundingClientRect().top + window.scrollY - 120, behavior: 'smooth' });
        });
      });
    }
    $$('a[data-filter-link]').forEach(function (a) {
      a.addEventListener('click', function () {
        store.set('cakeu-filter', a.getAttribute('data-filter-link'));
      });
    });

    /* gallery */
    galItems = $$('.gal-item');
    galItems.forEach(function (it, i) {
      it.tabIndex = 0;
      it.setAttribute('role', 'button');
      it.setAttribute('aria-label', 'View larger: ' + (($('img', it) || {}).alt || 'photo'));
      function open() { openLightbox(i); }
      it.addEventListener('click', open);
      it.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
      });
    });

    /* product detail thumbnails */
    var pdpMain = document.getElementById('pdp-main');
    if (pdpMain) {
      $$('.pdp-thumbs img').forEach(function (t) {
        t.tabIndex = 0;
        t.setAttribute('role', 'button');
        function swap() {
          var src = t.getAttribute('data-src') || t.src;
          pdpMain.classList.add('fade-swap');
          setTimeout(function () { pdpMain.src = src; pdpMain.classList.remove('fade-swap'); }, 140);
          $$('.pdp-thumbs img').forEach(function (o) { o.classList.remove('on'); });
          t.classList.add('on');
        }
        t.addEventListener('click', swap);
        t.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); swap(); }
        });
      });
    }

    /* quick WhatsApp links written in HTML */
    $$('[data-wa]').forEach(function (el) {
      el.setAttribute('href', waLink(el.getAttribute('data-wa')));
      el.setAttribute('target', '_blank');
      el.setAttribute('rel', 'noopener');
    });

    /* wide tables: mark those that actually scroll so CSS can hint a swipe */
    $$('.table-wrap').forEach(function (wrap) {
      var mark = function () {
        var over = wrap.scrollWidth - wrap.clientWidth > 4;
        if (over) { wrap.setAttribute('data-scrollable', ''); } else { wrap.removeAttribute('data-scrollable'); }
      };
      mark();
      window.addEventListener('resize', mark);
    });

    /* planner */
    initPlanner();

    /* footer year */
    $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
  }

  /* ---------- cake size & budget planner ---------- */
  function initPlanner() {
    var form = document.getElementById('planner-form');
    if (!form || form._ready) return;
    form._ready = true;

    var CHECK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 12.5 9.5 17.5 20 6.5"/></svg>';
    var SIZES = [
      { kg: '½ kg',  serves: [2, 3],   classic: 350,  premium: 430 },
      { kg: '1 lb',  serves: [4, 5],   classic: 650,  premium: 750 },
      { kg: '1½ lb', serves: [7, 8],   classic: 950,  premium: 1100 },
      { kg: '2 lb',  serves: [9, 10],  classic: 1250, premium: 1450 },
      { kg: '3 lb',  serves: [14, 16], classic: 1850, premium: 2200 }
    ];
    var DESIGN_ADD = { simple: 0, medium: 250, elaborate: 550 };
    var OCCASION_NOTE = {
      birthday: 'a name and age written on the cake, plus candles',
      anniversary: 'elegant piping and a message plaque',
      babyshower: 'soft pastel colours and a topper',
      wedding: 'two tiers, colour-matched frosting and fresh flowers',
      office: 'individually packed portions so it is easy to share',
      festival: 'festival colours and a small note card',
      casual: 'simply the flavour you love, nothing fussy'
    };
    var DESSERT_IDEAS = {
      classic: ['brownies, box of 6 — ₹450', 'jar desserts — ₹150 each', 'cupcakes — ₹50 each'],
      premium: ['tiramisu box, serves 4 — ₹750', 'tiramisu cups — ₹120 each', 'cupcakes — ₹50 each'],
      dessert: ['tiramisu box, serves 4 — ₹750', 'jar dessert set of 4 — ₹560', 'brownie slab 500 g — ₹700']
    };
    var plMsg = '';
    function money(n) { return '₹' + n.toLocaleString('en-IN'); }
    function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
    function num(id) { return parseInt(val(id) || '0', 10) || 0; }

    function calculate() {
      var guests = Math.max(1, num('pl-guests'));
      var flavour = val('pl-flavour'), design = val('pl-design'), occasion = val('pl-occ'), budget = num('pl-budget');

      if (flavour === 'dessert') {
        var boxes = Math.max(1, Math.ceil(guests / 4));
        var dLow = boxes * 450, dHigh = boxes * 800;
        return {
          title: 'Dessert table for ' + guests,
          lines: [
            '<b>' + boxes + ' dessert portion' + (boxes > 1 ? 's' : '') + '</b> — tiramisu boxes (each serves about 4) or a mix of jars and brownies',
            'Indicative: <b>' + money(dLow) + ' – ' + money(dHigh) + '</b>',
            'Budget check: ' + (budget ? (budget >= dLow ? 'Yes — this fits your ' + money(budget) + ' budget.' : 'Slightly tight for ' + money(budget) + '; a jar-only table would fit.') : 'Tell us a budget and we will shape the table around it.'),
            'Nice with it: ' + DESSERT_IDEAS.dessert.join(' · ')
          ],
          wa: 'Dessert table for ' + guests + ' guests. Budget: ' + (budget ? money(budget) : 'flexible')
        };
      }

      var chosen = SIZES[SIZES.length - 1];
      for (var i = 0; i < SIZES.length; i++) {
        if (SIZES[i].serves[1] >= guests) { chosen = SIZES[i]; break; }
      }
      if (guests > SIZES[SIZES.length - 1].serves[1]) {
        var tiers = Math.ceil(guests / SIZES[SIZES.length - 1].serves[1]);
        chosen = { kg: tiers + ' × 3 lb' + (tiers > 1 ? ' (' + tiers + ' tiers)' : ''),
                   serves: [tiers * 14, tiers * 16], classic: 1850 * tiers, premium: 2200 * tiers };
      }
      var base = (flavour === 'premium') ? chosen.premium : chosen.classic;
      var add = DESIGN_ADD[design] || 0;
      var low = base + add, high = Math.round((base + add + 250) / 50) * 50;
      var within = budget
        ? (high <= budget ? 'Yes — this fits your ' + money(budget) + ' budget, with room for cupcakes.'
          : (low <= budget ? 'Almost — we can trim the design to fit ' + money(budget) + '.'
            : 'Your ' + money(budget) + ' budget is below this plan; a smaller size or simpler design would work.'))
        : 'Send us a budget and we will shape the size and design to fit.';

      return {
        title: chosen.kg + ' cake for ' + guests + ' guests',
        lines: [
          'Serves <b>' + chosen.serves[0] + '–' + chosen.serves[1] + '</b> as a dessert portion (more if there are other sweets).',
          (flavour === 'premium' ? 'Premium flavours' : 'Classic flavours') + ' — <b>' + money(base) + '</b>',
          (design === 'simple' ? 'Simple finish — no extra charge.'
            : (design === 'medium' ? 'Medium design work — about ' + money(add) + ' extra.'
              : 'Elaborate design work (number cake, photo print or fondant figures) — about ' + money(add) + ' extra.')),
          'Indicative total: <b>' + money(low) + ' – ' + money(high) + '</b>',
          'Budget check: ' + within,
          'Nice with it: ' + DESSERT_IDEAS[flavour === 'premium' ? 'premium' : 'classic'].slice(0, 2).join(' · '),
          'Design note: ' + OCCASION_NOTE[occasion] + '.'
        ],
        wa: chosen.kg + ' ' + (flavour === 'premium' ? 'premium' : 'classic') + ' cake for ' + guests +
            ' guests (' + occasion + ', ' + design + ' design). Budget: ' + (budget ? money(budget) : 'flexible')
      };
    }

    function render(res) {
      var t = document.getElementById('pl-title');
      if (t) t.textContent = res.title;
      var body = document.getElementById('pl-body');
      if (body) body.innerHTML = '';
      var lines = document.getElementById('pl-lines');
      if (lines) lines.innerHTML = '<ul class="value-list">' + res.lines.map(function (l) {
        return '<li>' + CHECK + '<div><p style="margin:0">' + l + '</p></div></li>';
      }).join('') + '</ul>';
      plMsg = 'Hello The Cakeu Kadai! 🍰 I used the planner on your website.\n\n' + res.wa +
              '\n\nName:\nDate needed:\nPickup or delivery:';
    }

    var calc = document.getElementById('pl-calc');
    if (calc) calc.addEventListener('click', function () { render(calculate()); });
    var sendBtn = document.getElementById('pl-send');
    if (sendBtn) sendBtn.addEventListener('click', function () {
      openExternal(waLink(plMsg), 'Plan ready! <a href="' + waLink(plMsg) + '" target="_blank" rel="noopener">Tap here to send it on WhatsApp</a>.');
    });
    ['pl-guests', 'pl-flavour', 'pl-design', 'pl-occ', 'pl-budget'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('change', function () { render(calculate()); });
    });
    render(calculate());
  }

  /* ---------- expose + boot ---------- */
  window.cakeuInitGlobal = initGlobal;
  window.cakeuInitPage = initPage;

  function boot() { initGlobal(); initPage(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
